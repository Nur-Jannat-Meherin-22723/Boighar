package com.admin.servlet;
/*
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.entity.BookDtls;


@WebServlet("/add_books")
@MultipartConfig
public class BooksAdd extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			
			String bookName= req.getParameter("bname");
			String author= req.getParameter("author");
			String price= req.getParameter("price");
			String categories= req.getParameter("categories");
			String status= req.getParameter("status");
			String fileName = req.getParameter("bimg");
			
			BookDtls b = new BookDtls(bookName,author,price,categories,status,fileName,"admin");
			System.out.println(b);

			
		
		}catch (Exception e){
			e.printStackTrace();
			
		}
		
		
	}

	
}
	*/
/*
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.DAO.BookDAOImpl;
import com.DB.DBConnect;
import com.entity.BookDtls;

@WebServlet("/add_books")
@MultipartConfig
public class BooksAdd extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String bookName = null;
            String author = null;
            String price = null;
            String categories = null;
            String status = null;
            String fileName = null;

            // Create a factory for disk-based file items
            DiskFileItemFactory factory = new DiskFileItemFactory();

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            // Parse the request
            List<FileItem> items = upload.parseRequest(req);

            // Process the form fields and uploaded files
            for (FileItem item : items) {
                if (item.isFormField()) {
                    // Process regular form fields
                    if ("bname".equals(item.getFieldName())) {
                        bookName = item.getString();
                    } else if ("author".equals(item.getFieldName())) {
                        author = item.getString();
                    } else if ("price".equals(item.getFieldName())) {
                        price = item.getString();
                    } else if ("categories".equals(item.getFieldName())) {
                        categories = item.getString();
                    } else if ("status".equals(item.getFieldName())) {
                        status = item.getString();
                    }
                } else {
                    // Process file uploads
                    fileName = new File(item.getName()).getName();
                    InputStream fileContent = item.getInputStream();
                    // Handle the file content as needed (e.g., saving to a directory)
                }
            

            BookDtls b = new BookDtls(bookName, author, price, categories, status, fileName, "admin");
//            System.out.println(b);
            
            BookDAOImpl dao = new BookDAOImpl(DBConnect.getConn());
            
            String path = getServletContext().getRealPath("") + "book";
           System.out.println(path);
            
            File f = new File(path);
//            Part.write(path+ File.separator + fileName);
            
            File uploadedFile = new File(path + File.separator + fileName);
            try (InputStream fileContent = item.getInputStream(); FileOutputStream out = new FileOutputStream(uploadedFile)) {
                byte[] buffer = new byte[1024];
                int bytesRead;
                while ((bytesRead = fileContent.read(buffer)) != -1) {
                    out.write(buffer, 0, bytesRead);
                }
            }

            
            
//            boolean f = dao.addBooks(b);
//            
//            HttpSession session = req.getSession();
//            
//            if(f)
//            {
//            	
//            	
//            	session.setAttribute("succMsg", "Book Add Successful!");
//            	resp.sendRedirect("admin/add_books.jsp");
//            }
//            else {
//            	session.setAttribute("failedMsg", "Something wrong on Server...");
//            	resp.sendRedirect("admin/add_books.jsp");
//			}
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
*/



import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.DAO.BookDAOImpl;
import com.DB.DBConnect;
import com.entity.BookDtls;

@SuppressWarnings("serial")
@WebServlet("/add_books")
@MultipartConfig
public class BooksAdd extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            String bookName = null;
            String author = null;
            String price = null;
            String categories = null;
            String status = null;
            String fileName = null;

            // Create a factory for disk-based file items
            DiskFileItemFactory factory = new DiskFileItemFactory();

            // Create a new file upload handler
            ServletFileUpload upload = new ServletFileUpload(factory);

            // Parse the request
            List<FileItem> items = upload.parseRequest(req);

            // Process the form fields and uploaded files
            for (FileItem item : items) 
            {
                if (item.isFormField()) {
                    // Process regular form fields
                    if ("bname".equals(item.getFieldName())) {
                        bookName = item.getString();
                    } else if ("author".equals(item.getFieldName())) {
                        author = item.getString();
                    } else if ("price".equals(item.getFieldName())) {
                        price = item.getString();
                    } else if ("categories".equals(item.getFieldName())) {
                        categories = item.getString();
                    } else if ("status".equals(item.getFieldName())) {
                        status = item.getString();
                    }
                } else {
                    // Process file uploads
                    fileName = new File(item.getName()).getName();
                    InputStream fileContent = item.getInputStream();
                    // Handle the file content as needed (e.g., saving to a directory)
                }
                String path = getServletContext().getRealPath("") + "book";
//              System.out.println(path);
              
              File file = new File(path);
//              Part.write(path+ File.separator + fileName);
              
              File uploadedFile = new File(path + File.separator + fileName);
              try (InputStream fileContent = item.getInputStream(); FileOutputStream out = new FileOutputStream(uploadedFile)) {
                  byte[] buffer = new byte[1024];
                  int bytesRead;
                  while ((bytesRead = fileContent.read(buffer)) != -1) {
                      out.write(buffer, 0, bytesRead);
                  }
            }
            }

            BookDtls b = new BookDtls(bookName, author, price, categories, status, fileName, "admin");
//            System.out.println(b);
            
            BookDAOImpl dao = new BookDAOImpl(DBConnect.getConn());
            
            boolean f = dao.addBooks(b);
            
            HttpSession session = req.getSession();
            
            if(f)
            {
            	session.setAttribute("succMsg", "Book Add Successful!");
            	resp.sendRedirect("admin/add_books.jsp");
            }
            else {
            	session.setAttribute("failedMsg", "Something wrong on Server...");
            	resp.sendRedirect("admin/add_books.jsp");
			}
        }

         catch (Exception e) {
            e.printStackTrace();
        }
    }
}



